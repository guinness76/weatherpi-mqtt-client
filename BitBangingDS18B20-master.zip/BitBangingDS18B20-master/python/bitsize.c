#include <stdio.h>
#include <stdlib.h>

void main(void)
{
  printf("int = %d\n",sizeof(int));
  printf("long = %d\n",sizeof(long));
  printf("long long = %d\n",sizeof(long long));

}
